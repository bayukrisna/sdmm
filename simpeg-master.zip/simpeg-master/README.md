No Longer Maintained
=========
Simpeg is no longer being maintained by me. Appologies to those of you that have invested time into this package. Feel free to fork it if you feel the need. Once again, I'm sorry, I just don't have the time.

simpeg
=========

Simple Employee Management Applications

Just simple employee management application with CodeIgniter and Twitter Bootstrap
